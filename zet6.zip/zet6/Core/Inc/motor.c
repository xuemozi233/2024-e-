#include "main.h"
#include "servo.h"
#include "tim.h"
#include "math.h"
#include "pid.h"
#define M_PI 3.14159265358979323846


float get_speed()
{
	
//   int32_t encoder_value = __HAL_TIM_GET_COUNTER(&htim4);	
//	 __HAL_TIM_SetCounter(&htim4, 32500);
//		float speed = (float)(encoder_value-32500)/2;
//	 return  speed;
}


float calculate_wheel_speed(int encoder_pulses, int cpr, float sample_period, int gear_ratio, float wheel_radius_mm) {
    // ��������ת�٣�RPM��
    float motor_rpm = (float)encoder_pulses * 60.0f / (cpr * sample_period);
    
    // ���㳵��ת�٣�RPM��
    float wheel_rpm = motor_rpm / gear_ratio;
    
    // ���㳵�����ٶȣ�mm/min��
    float wheel_speed_mm_per_min = wheel_rpm * 2.0f * M_PI * wheel_radius_mm;
    
    // ת��Ϊ mm/s
    float wheel_speed_mm_per_s = wheel_speed_mm_per_min / 60.0f;
    
    return wheel_speed_mm_per_s;
}





void motor_forward()
{
 HAL_GPIO_WritePin(GPIOG, GPIO_PIN_12, GPIO_PIN_SET);
 HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_RESET);
}
	
	
	void motor_reverse()
{
 HAL_GPIO_WritePin(GPIOG, GPIO_PIN_12, GPIO_PIN_RESET);
 HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_SET);
}

	void motor_stop()
{

 HAL_GPIO_WritePin(GPIOG, GPIO_PIN_12|GPIO_PIN_13, GPIO_PIN_RESET);
}

