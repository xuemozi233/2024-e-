#include "pid.h"

void PID_Init(PID_HandleTypeDef *pid, float Kp, float Ki, float Kd) {
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->setpoint = 0.0;
    pid->integral = 0.0;
    pid->prev_error = 0.0;
    pid->output = 0.0;
}

float PID_Compute(PID_HandleTypeDef *pid, float input) {
    float error = pid->setpoint - input;
    pid->integral += error;
    float derivative = error - pid->prev_error;
    pid->output = pid->Kp *derivative + pid->Ki * error + pid->Kd * derivative;
    pid->prev_error = error;
    return pid->output;
}


//float PID_Increment(PID_Increment_Struct *PID, float Current, float Target)
//{
//		 float err,                                                                                                         //���
//          out,                                                                                                         //���
//          proportion,                                                                                                  //����
//          differential;                                                                                                //΢��
//    err = (float)Target - (float)Current;                                                                            //�������
//    proportion = (float)err - (float)PID->Error_Last1;                                                               //���������
//    differential = (float)err - 2 * (float)PID->Error_Last1 + (float)PID->Error_Last2;                               //����΢����
//    out = (float)PID->Out_Last + (float)PID->Kp * proportion + (float)PID->Ki * err + (float)PID->Kd * differential; //����PID
//    PID->Error_Last2 = PID->Error_Last1;                                                                             //�������ϴ����
//    PID->Error_Last1 = err;                                                                                          //�������
//    PID->Out_Last = out;                                                                                             //�����ϴ����
//    return out;
//}