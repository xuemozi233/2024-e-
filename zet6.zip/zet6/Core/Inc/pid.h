#ifndef PID_H
#define PID_H

typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float setpoint;
    float integral;
    float prev_error;
    float output;
} PID_HandleTypeDef;



void PID_Init(PID_HandleTypeDef *pid, float Kp, float Ki, float Kd);
float PID_Compute(PID_HandleTypeDef *pid, float input);
// float PID_Increment(PID_Increment_Struct *PID, float Current, float Target)

#endif // PID_H
