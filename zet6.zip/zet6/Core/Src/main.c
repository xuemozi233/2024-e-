/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "servo.h"
#include "steppermotor.h"
#include "OLED.h"
#include "OLED_Data.h"
#include "math.h"
#include "mpu6050.h"
//#include "motor.h"
#include "pid.h"
#include "sr04.h"
#include "matrix_key.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

//�ض���
int fputc(int c,FILE *stream)
{
	uint8_t ch[1]={c};
	HAL_UART_Transmit(&huart1,ch,1,0xFFFF);
	return c;
}

int keyScan(void);

int keyScan(void)
{
	HAL_GPIO_WritePin(GPIOF, COL1_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOF, COL2_Pin|COL3_Pin|COL4_Pin, GPIO_PIN_SET);
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 4\r\n", 8, 0XFFFF);
		return 13;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 8\r\n", 8, 0XFFFF);
		return 9;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 12\r\n", 9, 0XFFFF);
		return 5;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 16\r\n", 9, 0XFFFF);
		return 1;
	}
	HAL_GPIO_WritePin(GPIOF, COL2_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOF, COL1_Pin|COL3_Pin|COL4_Pin, GPIO_PIN_SET);
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 3\r\n", 9, 0XFFFF);
		return 14;
	}
	

	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 7\r\n", 9, 0XFFFF);
		return 10;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 11\r\n", 9, 0XFFFF);
		return 6;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 15\r\n", 9, 0XFFFF);
		return 2;
	}
	HAL_GPIO_WritePin(GPIOF, COL3_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOF, COL1_Pin|COL2_Pin|COL4_Pin, GPIO_PIN_SET);
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 2\r\n", 9, 0XFFFF);
		return 15;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 6\r\n", 9, 0XFFFF);
		return 11;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 10\r\n", 9, 0XFFFF);
		return 7;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 14\r\n", 9, 0XFFFF);
		return 3;
	}
	HAL_GPIO_WritePin(GPIOF, COL4_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOF, COL1_Pin|COL2_Pin|COL3_Pin, GPIO_PIN_SET);
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW4_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 1\r\n", 9, 0XFFFF);
		return 16;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW3_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 5\r\n", 9, 0XFFFF);
		return 12;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW2_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 9\r\n", 9, 0XFFFF);
		return 8;
	}
	if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin))
	{
		HAL_Delay(20);
		if(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin))
		{

		}
		while(GPIO_PIN_RESET == HAL_GPIO_ReadPin(GPIOF, ROW1_Pin));
		//HAL_UART_Transmit(&huart2, (uint8_t *)"key: 13\r\n", 9, 0XFFFF);
		return 4;
	}
	return 0;
}
void LED(int led)
{
	if(led==0)
	{
	HAL_GPIO_WritePin(GPIOE, LED_RED_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOE, LED_GRENN_Pin, GPIO_PIN_RESET);
	}
	if(led==1)
	{
	HAL_GPIO_WritePin(GPIOE, LED_RED_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOE, LED_GRENN_Pin, GPIO_PIN_SET);
	}

}

void electromagnet(int electromagnet)
{
	if(electromagnet==0)
	{
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_RESET);
	}
	if(electromagnet==1)
	{
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_SET);
	}

}

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define ZUOYI() \
    do { \
        Set_angle(-25, -45, 42, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-25, 35, 42, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-25, -45, 42, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define ZUOER() \
    do { \
        Set_angle(-22, -45, 32, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-22, 40, 32, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-22, -45, 32, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define ZUOSAN() \
    do { \
        Set_angle(-19, -45, 19, -70); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-19, 42, 19, -70); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-19, -45, 19, -70); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define ZUOSI() \
    do { \
        Set_angle(-16, -45, 3, -60); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-16, 50, 3, -60); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-16, -45, 4, -60); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define ZUOWU() \
    do { \
        Set_angle(-15, -45, -20, -42); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-15, 56, -20, -42); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-15, -45, -20, -42); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define YOUYI() \
    do { \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(21, -45, 44, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(21, 35, 44, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(21, -45, 44, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define YOUER() \
    do { \
        Set_angle(19, -45, 33, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(19, 40, 33, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(19, -45, 33, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define YOUSAN() \
    do { \
        Set_angle(17, -45, 18, -70); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(17, 43, 18, -70); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(17, -45, 18, -70); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define YOUSI() \
    do { \
        Set_angle(15, -45, 4, -60); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(15, 48, -1, -60); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(15, -45, 4, -60); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define YOUWU() \
    do { \
        Set_angle(13, -45, -20, -42); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(13, 57, -20, -42); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(14, -45, -20, -42); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define GEYI() \
    do { \
        Set_angle(9, -45, 42, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(9, 35, 42, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
									electromagnet(OFF);\
        Set_angle(9, -45, 42, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define GEER() \
    do { \
        Set_angle(-2, -45, 43, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-2, 35, 43, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
									electromagnet(OFF);\
        Set_angle(-2, -45, 43, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define GESAN() \
    do { \
        Set_angle(-12, -45, 41, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-12, 35, 41, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
									electromagnet(OFF);\
        Set_angle(-12, -45, 41, -90); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define GESI() \
    do { \
        Set_angle(8, -45, 29, -87); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(8, 41, 29, -87); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
									electromagnet(OFF);\
        Set_angle(8, -45, 29, -87); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define GELIU() \
    do { \
        Set_angle(-11, -45, 29, -89); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-11, 41, 29, -89); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
									electromagnet(OFF);\
        Set_angle(-11, -45, 29, -89); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define GEQI() \
    do { \
        Set_angle(7, -45, 15, -69); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(7, 44, 15, -69); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
									electromagnet(OFF);\
        Set_angle(7, -45, 15, -69); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define GEBA() \
    do { \
        Set_angle(-2, -45, 15, -69); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-2, 44, 15, -69); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
									electromagnet(OFF);\
        Set_angle(-2, -45, 15, -69); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define GEJIU() \
    do { \
        Set_angle(-8, -45, 13, -69); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-8, 44, 13, -69); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
									electromagnet(OFF);\
        Set_angle(-8, -45, 13, -69); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)

#define GEWU() \
    do { \
        Set_angle(-1, -45, 31, -89); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(-1, 42, 31, -89); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
				electromagnet(OFF);\
        Set_angle(-1, -45, 31, -89); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
        Set_angle(0, -45, 0, 0); \
        while (servo_flag != 1) {} \
        servo_flag = 0; \
    } while (0)





/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
 sr04_t sr04;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
	int Flage = 0;
	uint8_t rx_buffer[100];
	uint8_t rx_buffer_4[32];
	char buffer[32];
	PID_HandleTypeDef pid;
	int servo1= 0, servo2=0;
	int result[4];  // �����ַ�����������10������v
	int result2[2];  // �����ַ�����������10������
	int count;
	int state[];
	
	int now_angle_1 = 0;
	int now_angle_2 = 0;
	int now_angle_3 = 0;
	int now_angle_4 = 0;
	
	extern int stepper_flage;
	extern int step_data;
	int count_stepper = 0;
	float speed1;
	
	int 	Placement_Completed = 0;     //���Ƿ���ɷ��õı�־   	Placement_Completed   
	int motor_pwm = 2500;
	
	int task_flage = 0;
	
	int encoder_pulses = 500;      // ��ȡ�������ڻ�õ�������
	int cpr = 1024;                // ��������ÿת������
	float sample_period = 0.02f;   // ȡ�����ڣ��룩
	int gear_ratio = 30;           // ���ٱ�
	float wheel_radius_mm = 60.0f; // ���ӵİ뾶�����ף�
	
	
	int key_task = 0;
	int key=0;
				   

	int grenn=1;
	int red=0;
	
	
	int ON = 1;
	int OFF = 0;
	
	int task4_situation=0;
	
	int tx_complete = 0;
	
	int servo_flag;
	int Servo_Flage;
	
	


	
	
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM2_Init();
  MX_USART1_UART_Init();
  MX_I2C2_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */

HAL_UART_Init(&huart1);
	

	OLED_Init();
  Servo_Init();

//	Set_angle(0 , 0, 80, -70);



		
//   char task[] = {1, 2, 3, 4};
	


// 
//	 				      YOUSI();
//	 
//	 

//			electromagnet(ON);
//	

//	
//	




// Set_angle(servo1, servo2);

// OLED_Printf(0,25,OLED_8X16, "%d", servo1);
// OLED_Printf(0,50,OLED_8X16, "%d", servo2);


//	HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));


 

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while(1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		LED(grenn);
		OLED_Clear();
		//����OLED������ʾ������ӡ����ģʽ
		OLED_Printf(0,0,OLED_8X16,"Waiting");
		OLED_Update();
//		HAL_UART_Receive_IT(&huart1, rx_buffer, sizeof(rx_buffer));
		        //  HAL_UART_Transmit_DMA(&huart1 ,"4", 1);
 key_task = 0;
		
 key_task =	keyScan();
	if(key_task>0)
{
		if(key_task<7)
	{
			

				//����OLED������ʾ������ӡ������ѡ��
				//1.��ģʽ
				//2.����ָ��ģʽ
				//3.������תģʽ
				//4.װ�����ж���ģʽ
				//5.�����ж���ģʽ
					 LED(grenn);
					 if(key_task==1)
					{
						LED(red);
						OLED_Clear();
						//����OLED������ʾ������ӡ����ģʽ
						OLED_Printf(0,0,OLED_8X16,"task one");
						OLED_Update();
						
						
						
		electromagnet(ON);
    YOUYI(); // ִ�� youyi ��
    GEWU();  // ִ�� gewu ��

	
	
	
						
//						Set_angle(60 , 0, 80, -70);//ץȡ
//						HAL_Delay(500);
//						Set_angle(-30 , 0, 80, -70);//����
//						HAL_Delay(500); 
						LED(grenn);		
						//���ö�������ں�������װ�ý����ӷ�����ŷ���
					}
					
					
					else				 if(key_task==6)
					{
						LED(red);
					OLED_Clear();

						OLED_Printf(0,0,OLED_8X16,"task six");
					OLED_Update();
//						
//						Set_angle(60 , 0, 80, -70);//ץȡ
//						HAL_Delay(500);
//						Set_angle(-30 , 0, 80, -70);//����
//						HAL_Delay(500); 
//	HAL_UART_Receive_IT(&huart1, rx_buffer, sizeof(rx_buffer));
						while(1)
						{
							HAL_UART_Receive_IT(&huart1, rx_buffer, sizeof(rx_buffer));
							HAL_Delay(10);
							
						}
						//���ö�������ں�������װ�ý����ӷ�����ŷ���
					}
					
					
					
					
					
					
					else if(key_task==2)
					{
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task two");
						OLED_Update();
					

						
						task_flage = 2;
						int Completed_number = 0; //�������ô���
						
					while(task_flage != 0)
					{	
							LED(grenn);
							key=keyScan();	
						while(key==0)
						{
						key=keyScan();	
						}
						
						if(key != 0){
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task two");
						OLED_Printf(0,50,OLED_8X16, "situation%dis%d",Completed_number+1, key);
						}
						OLED_Update();
						
				
						if(Completed_number >= 0){
						   LED(red);
							if(Completed_number==0)
							{
								YOUYI();
							}
						  if(Completed_number==1)
							{
					      YOUER();
							}							
						 if(Completed_number==2)
							{
							  ZUOYI();
							}		
						 if(Completed_number==3)
							{
								ZUOER();
							}									
						switch (key) {
				case 1:

						GEYI();
						Completed_number =Completed_number + 1;
							
            break;
						 
        case 2:
						GEER();
						Completed_number =Completed_number + 1;

            break;
        case 3:
						GESAN();
						Completed_number =Completed_number + 1;
            break;
        case 4:
						GESI();
						Completed_number =Completed_number + 1;
            break;
        case 5:
						GEWU()  ;
						Completed_number =Completed_number + 1;
            break;
        case 6:
						GELIU ();
						Completed_number =Completed_number + 1;
            break;
        case 7:
						GEQI() ;
						Completed_number =Completed_number + 1;
            break;
        case 8:
						GEBA() ;
						Completed_number =Completed_number + 1;
            break;
        case 9:
						GEJIU();
						Completed_number =Completed_number + 1;
            break;
        default:
            break;
						
			}
						
						}			
						
						

						if(Completed_number==4)
						{
						task_flage=0;
						}
						
						
						
					}
		
					}
					
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						


					else if(key_task==4)
					{	

						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Update();
							
						task_flage = 4;	
						Flage=0;
						
						YOUYI();		

						
						LED(grenn);
					//	const uint8_t a=4;
						
						
													 

							 							 

							 
						
						
						
						
						//ѡ���������λ��
						key=keyScan();	
						while(key==0)
						{
						key=keyScan();	
							
						}
						
						
						switch (key) {
				case 1:

						GEYI();
					
							
            break;
						 
        case 2:
						GEER();
						
            break;
        case 3:
						GESAN();
					
            break;
        case 4:
						GESI();
						
            break;
        case 5:
						GEWU()  ;
						
            break;
        case 6:
						GELIU ();
					
            break;
        case 7:
						GEQI() ;
					
            break;
        case 8:
						GEBA() ;
						
            break;
        case 9:
						GEJIU();
					
            break;
        default:
            break;
						
			}
						
						
			
			
			
						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", key);
						OLED_Update(); 
			
						int Completed_number_4 = 1;
						Placement_Completed  =0;
						
						while(Placement_Completed == 0)
						 {

									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
//								  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));
									break;
									}
						 }
						
						YOUER();
						
						
						HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
            HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));


						



						
						

						
						while (1)
						{

							


						LED(grenn);
//						key=keyScan();	
//						while(key==0)
//						{
//						key=keyScan();	
//						}
//						
//						if(key != 0){
//						OLED_Clear();
//						OLED_Printf(0,0,OLED_8X16,"task two");
//						OLED_Printf(0,50,OLED_8X16, "situation%dis%d",Completed_number+1, key);
//						}
//						OLED_Update();
//						
//				
//						if(Completed_number_4 >= 0){
//						   LED(red);
//							if(Completed_number_4==0)
//							{
//								YOUYI();
//							}
//						  if(Completed_number_4==1)
//							{
//					      YOUER();
//							}							
//						 if(Completed_number_4==2)
//							{
//							  ZUOYI();
//							}		
//						 if(Completed_number_4==3)
//							{
//								ZUOER();
//							}										
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
						Placement_Completed  =0;
         //   HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));
	
	        //  HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));

			 for (int i = 0; i <11&& rx_buffer_4[i] != '\0'; i++)
		{
				OLED_Printf(i * 16,16,OLED_6X8, "%d", rx_buffer_4[i]);
		}	

							
						OLED_Update(); 

			
		
		
			if(task4_situation==1 && Flage==1)
			     {
						HAL_UART_DeInit(&huart1);
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						 

					GEYI();
					Completed_number_4=Completed_number_4+1;

						 						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						
						while(Placement_Completed == 0)
						 {
							 

							 
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
//								  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));
										break;
									}
						 }
						 
						 
							if(Completed_number_4 >= 0){
						   LED(red);
							if(Completed_number_4==2)
							{
								YOUSAN();
							}
						  if(Completed_number_4==3)
							{
					      YOUSI();
							}							
						 if(Completed_number_4==4)
							{
							  YOUWU();
							}		
						}
						 
						 
						 
						 
						 
						 
						 
						 
						 
						 
						 
						Flage = 0;
     
			HAL_UART_Init(&huart1);
			HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
     HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));  //�����ٴ�ʶ�����Ϣ
			}
											
			else if(task4_situation==2 && Flage==1)
			{
						HAL_UART_DeInit(&huart1);
				
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						 
						GEER();
					Completed_number_4=Completed_number_4+1;

						 						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						while(Placement_Completed == 0)
						 {
							 
							 

									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
//								  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));									break;
									}
						 }
						 
						 							if(Completed_number_4 >= 0){
						   LED(red);
							if(Completed_number_4==2)
							{
								YOUSAN();
							}
						  if(Completed_number_4==3)
							{
					      YOUSI();
							}							
						 if(Completed_number_4==4)
							{
							  YOUWU();
							}		
						}
						 
						 
						 						Flage = 0;
       
			HAL_UART_Init(&huart1);
			HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
     HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));  //�����ٴ�ʶ�����Ϣ
			}								
			else if(task4_situation==3 && Flage==1)
			{
						HAL_UART_DeInit(&huart1);

						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						 
 GESAN();
					Completed_number_4=Completed_number_4+1;

						 						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
				
				
						while(Placement_Completed == 0)
						 {

									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
							//	  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));								break;
									}
						 }
						 
						 							if(Completed_number_4 >= 0){
						   LED(red);
							if(Completed_number_4==2)
							{
								YOUSAN();
							}
						  if(Completed_number_4==3)
							{
					      YOUSI();
							}							
						 if(Completed_number_4==4)
							{
							  YOUWU();
							}		
						}
						 
						 
						 						Flage = 0;
			HAL_UART_Init(&huart1);
			HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
     HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));  //�����ٴ�ʶ�����Ϣ
			}								
		else	if(task4_situation==4 && Flage==1)
			{
										HAL_UART_DeInit(&huart1);
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						 
GESI() ;
					Completed_number_4=Completed_number_4+1;

						 						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						while(Placement_Completed == 0)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
				//				  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));									break;
									}
						 }
						 
						 							if(Completed_number_4 >= 0){
						   LED(red);
							if(Completed_number_4==2)
							{
								YOUSAN();
							}
						  if(Completed_number_4==3)
							{
					      YOUSI();
							}							
						 if(Completed_number_4==4)
							{
							  YOUWU();
							}		
						}
						 
						 
						 						Flage = 0;
 
			HAL_UART_Init(&huart1);
			HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
     HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));  //�����ٴ�ʶ�����Ϣ
			}								
		else	if(task4_situation==5 && Flage==1)
			{
						HAL_UART_DeInit(&huart1);
				
				
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						 
GEWU();
					Completed_number_4=Completed_number_4+1;

						 						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						while(Placement_Completed == 0)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
				//				  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));									break;
									}
						 }
						 					

							if(Completed_number_4 >= 0){
						   LED(red);
							if(Completed_number_4==2)
							{
								YOUSAN();
							}
						  if(Completed_number_4==3)
							{
					      YOUSI();
							}							
						 if(Completed_number_4==4)
							{
							  YOUWU();
							}		
						}



						 Flage = 0;
						 
			HAL_UART_Init(&huart1);
			HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
     HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));  //�����ٴ�ʶ�����Ϣ
			}
				else		if(task4_situation==6 && Flage==1)
			{
						HAL_UART_DeInit(&huart1);
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						 
 GELIU();
					Completed_number_4=Completed_number_4+1;

						 						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						while(Placement_Completed == 0)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
			//					  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));								break;
									}
						 }
						 					
							if(Completed_number_4 >= 0){
						   LED(red);
							if(Completed_number_4==2)
							{
								YOUSAN();
							}
						  if(Completed_number_4==3)
							{
					      YOUSI();
							}							
						 if(Completed_number_4==4)
							{
							  YOUWU();
							}		
						}



						 Flage = 0;
    
			HAL_UART_Init(&huart1);
			HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
     HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));  //�����ٴ�ʶ�����Ϣ
			}
			
			else				if(task4_situation==7&&Flage==1)
			{
						HAL_UART_DeInit(&huart1);
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						 
GEQI();
					Completed_number_4=Completed_number_4+1;

						 						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update();  
						while(Placement_Completed == 0)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
				//				  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));									break;
									}
						 }
						 					
							if(Completed_number_4 >= 0){
						   LED(red);
							if(Completed_number_4==2)
							{
								YOUSAN();
							}
						  if(Completed_number_4==3)
							{
					      YOUSI();
							}							
						 if(Completed_number_4==4)
							{
							  YOUWU();
							}		
						}




						 Flage = 0;
     
			HAL_UART_Init(&huart1);
			HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
     HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));  //�����ٴ�ʶ�����Ϣ
			}	
			
			
			
			else			if(task4_situation== 8 && Flage==1)
			{
						HAL_UART_DeInit(&huart1);
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						 
GEBA();
					Completed_number_4=Completed_number_4+1;

						 						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						while(Placement_Completed == 0)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
				//				  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));									break;
									}
						 }
						 			
							if(Completed_number_4 >= 0){
						   LED(red);
							if(Completed_number_4==2)
							{
								YOUSAN();
							}
						  if(Completed_number_4==3)
							{
					      YOUSI();
							}							
						 if(Completed_number_4==4)
							{
							  YOUWU();
							}		
						}





						 Flage = 0;
   
			HAL_UART_Init(&huart1);
			HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
     HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));  //�����ٴ�ʶ�����Ϣ
			}
			
			
			
			
			
			else				if(task4_situation==9 && Flage==1)
			{
						HAL_UART_DeInit(&huart1);
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task four");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update(); 
						 
						 
					GEJIU();
					Completed_number_4=Completed_number_4+1;

						 						OLED_Clear();
						OLED_Printf(0,0,OLED_6X8, "Please make a move.");
						OLED_Printf(0,25,OLED_6X8, "computer's move is at:");						OLED_Printf(0,50,OLED_8X16, "%d", task4_situation);
						OLED_Update();  
						while(Placement_Completed == 0)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
					//			  memset(rx_buffer_4, 0, sizeof(rx_buffer_4));									break;
									}
						 }
					
							if(Completed_number_4 >= 0){
						   LED(red);
							if(Completed_number_4==2)
							{
								YOUSAN();
							}
						  if(Completed_number_4==3)
							{
					      YOUSI();
							}							
						 if(Completed_number_4==4)
							{
							  YOUWU();
							}		
						}




						 Flage = 0;
      
			HAL_UART_Init(&huart1);
			HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));
     HAL_UART_Transmit_DMA(&huart1 ,"4", strlen("4"));  //�����ٴ�ʶ�����Ϣ
			}
			
			
			
			

							if(task_flage==0 &&Flage==1)
							{
							  break;
							}
						}
					}
						

				  else	 if(key_task==5)
					{
						OLED_Clear();
						OLED_Printf(0,0,OLED_8X16,"task five");
						OLED_Update();

						
						task_flage=5;
						while(task_flage != 0)
						{
						  key=keyScan();

						if(key==11)
									{
						
            HAL_UART_Transmit_DMA(&huart1 ,"5", 1);
						
						HAL_UART_Receive_IT(&huart1, rx_buffer, sizeof(rx_buffer));
										
						while (Flage != 1 && task_flage==0 )
						{
							
							Placement_Completed  =0;
									   switch (rx_buffer[1]) {
        case 1:
						Placement_Completed = 0;
						Set_angle(0 , 0, 80, -70);//ץȡ
						Set_angle(0 , 0, 80, -70);//����
						
						while(Placement_Completed != 1)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
									}
						 }
						HAL_UART_Transmit_DMA(&huart1 ,"5", 1);   //�����ٴ�ʶ�����Ϣ
            break;
						 
        case 2:
						Placement_Completed = 0;
						Set_angle(0 , 0, 80, -70);//ץȡ
						Set_angle(0 , 0, 80, -70);//����
						
						while(Placement_Completed != 1)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
									}
						 }
						HAL_UART_Transmit_DMA(&huart1 ,"5", 1);   //�����ٴ�ʶ�����Ϣ

            break;
        case 3:
						Placement_Completed = 0;
						Set_angle(0 , 0, 80, -70);//ץȡ
						Set_angle(0 , 0, 80, -70);//����
						
						while(Placement_Completed != 1)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
									}
						 }
						HAL_UART_Transmit_DMA(&huart1 ,"5", 1);   //�����ٴ�ʶ�����Ϣ
            break;
        case 4:
						Placement_Completed = 0;
						Set_angle(0 , 0, 80, -70);//ץȡ
						Set_angle(0 , 0, 80, -70);//����
						
						while(Placement_Completed != 1)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
									}
						 }
						HAL_UART_Transmit_DMA(&huart1 ,"5", 1);   //�����ٴ�ʶ�����Ϣ
            break;
        case 5:
						Placement_Completed = 0;
						Set_angle(0 , 0, 80, -70);//ץȡ
						Set_angle(0 , 0, 80, -70);//����
						
						while(Placement_Completed != 1)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
									}
						 }
						HAL_UART_Transmit_DMA(&huart1 ,"5", 1);   //�����ٴ�ʶ�����Ϣ
            break;
        case 6:
						Placement_Completed = 0;
						Set_angle(0 , 0, 80, -70);//ץȡ
						Set_angle(0 , 0, 80, -70);//����
						
						while(Placement_Completed != 1)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
									}
						 }
						HAL_UART_Transmit_DMA(&huart1 ,"5", 1);   //�����ٴ�ʶ�����Ϣ
            break;
        case 7:
						Placement_Completed = 0;
						Set_angle(0 , 0, 80, -70);//ץȡ
						Set_angle(0 , 0, 80, -70);//����
						
						while(Placement_Completed != 1)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
									}
						 }
						HAL_UART_Transmit_DMA(&huart1 ,"5", 1);   //�����ٴ�ʶ�����Ϣ
            break;
        case 8:
						Placement_Completed = 0;
						Set_angle(0 , 0, 80, -70);//ץȡ
						Set_angle(0 , 0, 80, -70);//����
						
						while(Placement_Completed != 1)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
									}
						 }
						HAL_UART_Transmit_DMA(&huart1 ,"5", 1);   //�����ٴ�ʶ�����Ϣ
            break;
        case 9:
						Placement_Completed = 0;
						Set_angle(0 , 0, 80, -70);//ץȡ
						Set_angle(0 , 0, 80, -70);//����
						
						while(Placement_Completed != 1)
						 {
									key = keyScan();
									if(key == 11)
									{
									Placement_Completed = 1;
									}
						 }
						HAL_UART_Transmit_DMA(&huart1 ,"5", 1);   //�����ٴ�ʶ�����Ϣ
            break;
        default:
            break;
            }
						}
						

						//��������ڵ�ģ��ִ�г�����ƻ�е�۵Ĵ��벿��(����ִ������������ʾ)��
					
					
									}
						}
					}
					
					
				
				










					
	}	
	
	
	
	
		
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	
		 		HAL_Delay(1); 
	}    //������whileѭ���ı߽�
	

  
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */


void extract_numbers(const char *str, int *result, int *count) {
	
	
	
	
    int number = 0;
    int is_number = 0;
    *count = 0;

    for (int i = 0; str[i] != '\0'; ++i) {
        if (isdigit(str[i])) {
            number = number * 10 + (str[i] - '0');
            is_number = 1;
        } else if (is_number) {
            result[(*count)++] = number;
            number = 0;
            is_number = 0;
        }
    }

    if (is_number) {
        result[(*count)++] = number;
    }
}











void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	
	//����2���ջص�
    if (huart->Instance == huart2.Instance) {

	 OLED_Clear();	 	
	
    for (int i = 0; i < sizeof(rx_buffer); ++i) {
        buffer[i] = (char)rx_buffer[i];
    }
		
		extract_numbers(buffer, result, &count);		
	 for (int i = 0; i <4 && result[i] != '\0'; i++)
		{
				OLED_Printf(i * 16,0,OLED_6X8, "%d", result[i]);
		}


			OLED_Update();
			Flage = 1;
			HAL_UART_Receive_IT(&huart2, rx_buffer, sizeof(rx_buffer));
    }
		
		
		
	//����1���ջص�	
	if (huart->Instance == huart1.Instance) {
//	 for (int i = 0; i <11&& rx_buffer[i] != '\0'; i++)
//		{
//				OLED_Printf(i * 10,25,OLED_6X8, "%d", rx_buffer[i]);
//		}
//		
//		if(task_flage==0){
//	
//	
//    for (int i = 0; i < sizeof(rx_buffer); ++i) {
//        buffer[i] = (char)rx_buffer[i];
//    }
//		
//		extract_numbers(buffer, result, &count);		
//	 for (int i = 0; i <11&& result[i] != '\0'; i++)
//		{
//				OLED_Printf(i * 10,25,OLED_6X8, "%d", result[i]);
//		}

//	}
		
		
		
		
	 if(task_flage==4)
	 {
//		 	
//		 	 OLED_Clear();	 	
	
		
//		 	 for (int i = 0; i <11&& rx_buffer_4[i] != '\0'; i++)
//		{
//				OLED_Printf(i * 16,0,OLED_6X8, "%d", rx_buffer_4[i]);
//		}

      task4_situation   =  rx_buffer_4[1]-48;
		 
		 
	    if(rx_buffer_4[0]-48 == 1)    //�ж��Ƿ����
			{
				task_flage = 0;
			}

       int chess_number = rx_buffer_4[1];
						OLED_Printf(0,25,OLED_6X8, "%d", chess_number);
		memset(rx_buffer_4, 0, sizeof(rx_buffer_4));
		HAL_UART_Receive_IT(&huart1, rx_buffer_4, sizeof(rx_buffer_4));

	 }
		
		
		 

//	
	 if(task_flage==5)
	 {
		 
		 
		 		 	 OLED_Clear();	 	
	

		 	 for (int i = 0; i <11&& rx_buffer[i] != '\0'; i++)
		{
				OLED_Printf(i * 16,0,OLED_6X8, "%d", rx_buffer[i]);
		}

		 
		 
		 
	    if(rx_buffer[0]-48 == 1)    //�ж��Ƿ����
			{
				task_flage = 0;
			}
	 
       int chess_number = rx_buffer[1];
							OLED_Printf(0,25,OLED_6X8, "%d", chess_number);
		 
		 

	 
	 }
 
		 
		 
		 
		 
		 
		 
		
 		  
	     for (int i = 0; i < sizeof(rx_buffer); ++i) {
        buffer[i] = (char)rx_buffer[i];
    }
		
		extract_numbers(buffer, result, &count);		
	 for (int i = 0; i <11&& result[i] != '\0'; i++)
		{
				OLED_Printf(i * 10,25,OLED_6X8, "%d", result[i]);
		}
//	 OLED_ShowString(0, 50, "NVIC_ing", OLED_8X16);
		OLED_Update();
			Flage = 1;
	 
	 
	 
	 
	 if(task_flage==0){

	 	HAL_UART_Receive_IT(&huart1, rx_buffer, sizeof(rx_buffer));
	 
	  }
    }
		
		
		
		
}


//void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
//    if (huart->Instance == USART1) {
//        tx_complete = 1;  // ���÷�����ɱ�־
//		OLED_ShowString(0, 30, "ok", OLED_8X16);
//		OLED_Update();
//    }
//}




void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM6)
    {
		if(count_stepper != step_data){
		count_stepper=count_stepper+1;
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5); 
		}
		
		if(count_stepper == step_data)
		{
		count_stepper = 0;
		stepper_flage = 1;
		}
    }

		
		
		
		if (htim->Instance == TIM7)
    {

//			speed1 = get_speed();
//			float speed = calculate_wheel_speed(speed1, cpr, sample_period, gear_ratio, wheel_radius_mm);
//			printf( "%f,%f\n",speed,pid.setpoint);
//		  PID_Compute(&pid, speed);
//			
//			motor_pwm = motor_pwm +pid.output;
//			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3,motor_pwm);	
//			OLED_Printf(0,0,OLED_8X16, "%f", speed);
//			OLED_Printf(0,25,OLED_8X16, "%f", pid.setpoint);
//			OLED_Printf(0,50,OLED_8X16, "%f",pid.output);
//			
//      
//			
//			OLED_Update();	

    }


}






























/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
