#include "main.h"
#include "servo.h"
#include "tim.h"
#include "math.h"
#include "pid.h"

int step_data;
int stepper_flage = 0;
extern int count_stepper;
//a4Ϊdir,a5Ϊstep
void Stepper_set(int DIR,int step)
{

	 step_data = step/2;
	
		//����ѡ��
	 if(DIR==1){ HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);}
	 if(DIR==0){ HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);}
	 
	 //HAL_TIM_Base_Start_IT(&htim6); 
	 
		while(count_stepper != step_data){
		count_stepper=count_stepper+1;
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5); 
				HAL_Delay(1);
		}

	 
	 
//	 while( stepper_flage == 0)
//	 {
//	 HAL_Delay(1);
//	 }


}

