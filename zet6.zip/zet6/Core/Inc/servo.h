#ifndef SERVO_H
#define SERVO_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"

// �궨��ͳ���
#define SERVO_MIN_PULSE_WIDTH 1000   // ��С������� (us)
#define SERVO_MAX_PULSE_WIDTH 2000   // ���������� (us)
#define SERVO_MID_PULSE_WIDTH 1500   // �м�λ��������� (us)
	
#define SERVO_MIN_ANGLE 0
#define SERVO_MAX_ANGLE 180
#define RAD_TO_DEG(x) ((x) * (180.0 / PI))
#define PI 3.14159265

// ��������
void Servo_Init(void);
void 	Set_angle(int angle_1 ,int angle_2,int angle_3,int angle_4);
void zuosan();
void zuosi( void);
void zuowu( void);
void yousi(void );
void youwu( void) ;
void yousan( void);
void geqi( void);
void geba(void );
void gejiu( void);
void gesi (void );
void geliu(void );
void geyi(void);
void geer(void);
void gesan();
void zuoyi(void);
void youer(void);
void youyi(void);
void zuoer(void);
void gewu(void);



//void calculate_servo_angles(float coefficient_x,float coefficient_y,int array[], int *servo1_angle, int *servo2_angle);


#ifdef __cplusplus
}
#endif

#endif // SERVO_H
