#ifndef STEPPERMOTOR_H
#define STEPPERMOTOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"


void Stepper_set(int DIR,int step);

#ifdef __cplusplus
}
#endif

#endif // SERVO_H

