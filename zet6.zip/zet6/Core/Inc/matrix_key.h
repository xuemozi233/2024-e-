#ifndef _MATRIX_KEY_H_
#define _MATRIX_KEY_H_


//#include "main.h"
//#include "stdio.h"

//void Matrix_ssKey_Pin_Init(void);
//int Matrix_Key_Scan(void);

void KEY_Init(void);
int key_scan(void);
#endif

