#include "servo.h"
#include "main.h"
#include "tim.h"
#include "math.h"
#include "pid.h"
#include "OLED.h"
extern int  servo_flag;
extern int now_angle_1;
extern int now_angle_2;
extern int now_angle_3;
extern int now_angle_4;
extern int Servo_Flage;
void Servo_Init(void)
{
    // ���� PWM
	  HAL_TIM_Base_Start(&htim2);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
		HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
}


//�ú������ö���ƶ��������Ƕ�
void 	Set_angle(int angle_1 ,int angle_2,int angle_3,int angle_4)
{
/*
��������pwm����Ϊ20ms
t = 0.5ms ������������ �����ת�� -90 ��500
t = 1.0ms ������������ �����ת�� -45��1000
t = 1.5ms ������������ �����ת�� 0��1500
t = 2.0ms ������������ �����ת�� 45��2000
t = 2.5ms ������������ �����ת�� 90�� 2500
*/
int data_1_now = (1500+100/9*-(now_angle_1));
int data_2_now = (1500+100/9*(now_angle_2));	
int data_3_now = (1500+100/9*(now_angle_3));
int data_4_now = (1500+100/9*-(now_angle_4));		
	
	
	
int data_1 = (1500+100/9*-(angle_1));
int data_2 = 1500+100/9*(angle_2);	
int data_3 = (1500+100/9*(angle_3));
int data_4 = 1500+100/9*-(angle_4);	
	
if(data_1>2500)	
{
	data_1=2500;
}
if(data_1<500)	
{
	data_1=500;
}
if(data_2>2500)	
{
	data_2=2500;
}
if(data_2<500)	
{
	data_2=500;
}
	if(data_3>2500)	
{
	data_3=2500;
}
if(data_3<500)	
{
	data_3=500;
}
	if(data_4>2500)	
{
	data_4=2500;
}
if(data_4<500)	
{
	data_4=500;
}
		
	

//__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4,data_4);	
//__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1,data_1);
//__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2,data_2);
//__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3,data_3);

servo_flag=0;	
	
 if(data_1 != data_1_now)
    {
        if(data_1>data_1_now)
        {
            while(1)
            {
                data_1_now=data_1_now+3;//һ��
								__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1,data_1_now);	

								HAL_Delay(4); 
                if(data_1<=data_1_now)
                {
					
					servo_flag=1;	
                    break;
                }
            }
        }
        else
        {
            while(1)
            {
                data_1_now=data_1_now-3;//һ��
								__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1,data_1_now);	

								HAL_Delay(4); 
                if(data_1>=data_1_now)
                {
					
					servo_flag=1;	
                    break;
                }
            }
        }
    }

	


if(data_2 != data_2_now)
    {
        if(data_2>data_2_now)
        {
            while(1)
            {
                data_2_now=data_2_now+3;//һ��
								__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2,data_2_now);	

								HAL_Delay(4); 
                if(data_2<=data_2_now)
                {
					
			servo_flag=1;	
                    break;
                }
            }
        }
        else 
        {
            while(1)
            {
                data_2_now=data_2_now-3;//һ��
								__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2,data_2_now);	

								HAL_Delay(4); 
                if(data_2>=data_2_now)
                {
					
				servo_flag=1;	
                    break;
                }
            }
        }
    }

		
		
		
 
		
		
		
if(data_4 != data_4_now)
{
		if(data_4>data_4_now)
		{
				while(1)
				{
						data_4_now=data_4_now+3;//һ��
						__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4,data_4_now);	

						HAL_Delay(4); 
						if(data_4<=data_4_now)
						{
							
								servo_flag=1;	
								break;
						}
				}
		}
		else 
		{
				while(1)
				{
						data_4_now=data_4_now-3;//һ��
						__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4,data_4_now);	

						HAL_Delay(4); 
						if(data_4>=data_4_now)
						{
							
								servo_flag=1;	
								break;
						}
				}
		}
}

	
 


if(data_3 != data_3_now)
    {
        if(data_3>data_3_now)
        {
            while(1)
            {
                data_3_now=data_3_now+3;//һ��
								__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3,data_3_now);	

								HAL_Delay(4); 
                if(data_3<=data_3_now)
                {
					
						servo_flag=1;	
                    break;
                }
            }
        }
        else
        {
            while(1)
            {
                data_3_now=data_3_now-3;//һ��
								__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3,data_3_now);	

								HAL_Delay(4); 
                if(data_3>=data_3_now)
                {
						servo_flag=1;	
                    break;
                }
            }
        }
    }		
		




//		
//		
//		
//		
//		
//		



now_angle_1  =   angle_1;
now_angle_2  =   angle_2;
now_angle_3  =   angle_3;
now_angle_4  =   angle_4;









	
}



//�ú������Լ��������������ԽǶ�,���������Ҫ�ƶ����ĽǶ�
//void calculate_servo_angles(float coefficient_x,float coefficient_y,int array[], int *servo1_angle, int *servo2_angle) {

//	  //������Ϊ��λ
//	  int x1 =     array[0];
//		int y1 =     array[1];
//		int x2 =     array[2];
//		int y2 =     array[3];
//	
//	
//    double angle1 = atan2( (x2-x1)*coefficient_x , 100 );
//    *servo1_angle = (int )RAD_TO_DEG(angle1) + now_angle_x;

//    // ����ڶ�������ĽǶ�
//    double angle2 = atan2( (y2-y1)*coefficient_y , 100 );
//    *servo2_angle =(int) RAD_TO_DEG(angle2) + now_angle_y;

//	

//	
//	
//    // ���Ƕ������ڶ���ķ�Χ��
////    if (servo1_angle < SERVO_MIN_ANGLE) servo1_angle = SERVO_MIN_ANGLE;
////    if (servo1_angle > SERVO_MAX_ANGLE) servo1_angle = SERVO_MAX_ANGLE;
////    if (servo2_angle < SERVO_MIN_ANGLE) servo2_angle = SERVO_MIN_ANGLE;
////    if (servo2_angle > SERVO_MAX_ANGLE) servo2_angle = SERVO_MAX_ANGLE;
//	
//	

//}






void zuosan()
{
	
	


	Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}
		Set_angle(-19,-45, 19,-70);//��3


	while(servo_flag!=1)
	{}
	
Set_angle(-19,42, 19,-70);//��3



while(servo_flag!=1)
		{}



Set_angle(-19,-45, 19,-70);//��3

	while(servo_flag!=1)
	{}



Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}




		
	Set_angle(0, -45,0,0);//

	while(servo_flag!=1)
	{}		
	
			Set_angle(7,-45, 15,-69);//��7

	
		while(servo_flag!=1)
		{}
		Set_angle(7,44, 15,-69);//��7
		while(servo_flag!=1)
		{}

			Set_angle(7,-45, 15,-69);//��7

	while(servo_flag!=1)
		{}
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}

	}
void zuosi(void)
{


	
	Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}
		Set_angle(-16,-45 ,3,-60);//����

	while(servo_flag!=1)
	{}
	
Set_angle(-16,50 ,3,-60);//����


while(servo_flag!=1)
		{}

	
		Set_angle(-16,-45 ,4,-60);;//����
	while(servo_flag!=1)
	{}


	
	Set_angle(0, -45,0,0);//

	while(servo_flag!=1)
	{}


}



void zuowu( void)
{


	Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}
		Set_angle(-15,-45,-20,-42);//����

	while(servo_flag!=1)
	{}
	
Set_angle(-15,56 ,-20,-42);//����


while(servo_flag!=1)
		{}

	
		
		Set_angle(-15,-45,-20,-42);//����
	while(servo_flag!=1)
	{}


	
	Set_angle(0, -45,0,0);//

	while(servo_flag!=1)
	{}

}







void youwu(void)
{
	

	
	Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}
		Set_angle(13,-45,-20,-42);//����

	while(servo_flag!=1)
	{}
	
Set_angle(13,57 ,-20,-42);//����


while(servo_flag!=1)
		{}

	
		
		Set_angle(14,-45,-20,-42);//����
	while(servo_flag!=1)
	{}


	
	Set_angle(0, -45,0,0);//

	while(servo_flag!=1)
	{}



}




void yousi(void)
{




	Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}
		Set_angle(15,-45 ,4,-60);//����

	while(servo_flag!=1)
	{}
	
Set_angle(15,48 ,-1,-60);//����


while(servo_flag!=1)
		{}

	
		Set_angle(15,-45 ,4,-60);;//����
	while(servo_flag!=1)
	{}


	
	Set_angle(0, -45,0,0);//

	while(servo_flag!=1)
	{}

}

	
void yousan(void)
{
		

		
	Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}
		Set_angle(17,-45, 18,-70);//��3


	while(servo_flag!=1)
	{}
	
Set_angle(17,43, 18,-70);//��3



while(servo_flag!=1)
		{}



Set_angle(17,-45, 18,-70);//��3

	while(servo_flag!=1)
	{}



Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}


}


void geqi(void)
{




			

	
			Set_angle(7,-45, 15,-69);//��7

	
		while(servo_flag!=1)
		{}
		Set_angle(7,44, 15,-69);//��7
		while(servo_flag!=1)
		{}

			Set_angle(7,-45, 15,-69);//��7

	while(servo_flag!=1)
		{}
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}
	


}








void geba(void)
{



			

	
			Set_angle(-2,-45, 15,-69);//��8

	
		while(servo_flag!=1)
		{}
		Set_angle(-2,44, 15,-69);//��8
		while(servo_flag!=1)
		{}

			Set_angle(-2,-45, 15,-69);//��8

	while(servo_flag!=1)
		{}
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}
	


}




void gejiu(void)
{



			

	
		Set_angle(-8,-45,13,-69);//��9

	
		while(servo_flag!=1)
		{}
		Set_angle(-8,44, 13,-69);//��9
		while(servo_flag!=1)
		{}

		Set_angle(-8,-45, 13,-69);//��9

	while(servo_flag!=1)
		{}
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}
	

}





void geliu( void)
{



			
	
	
	Set_angle(-11,-45, 29,-89);//��6

	
		while(servo_flag!=1)
		{}
		Set_angle(-11,41, 29,-89);//��6
		while(servo_flag!=1)
		{}

  Set_angle(-11,-45, 29,-89);//��6

	while(servo_flag!=1)
		{}
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}
	


}




void gesi (void)
{


	
	

	
	Set_angle(8, -45,29,-87);//��4

	
		while(servo_flag!=1)
		{}
		Set_angle(8, 41,29,-87);//��4

		while(servo_flag!=1)
		{}
			
 	Set_angle(8, -45,29,-87);//��4


	while(servo_flag!=1)
		{}
		
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}
	
}

	

void geyi(void)
	
{


	
	
	
	
	Set_angle(9, -45,42,-90);//��1

	
		while(servo_flag!=1)
		{}
		Set_angle(9, 35,42,-90);//��1

		while(servo_flag!=1)
		{}
			
Set_angle(9, -45,42,-90);//��1


	while(servo_flag!=1)
		{}
		
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}
	}






void geer(void)
	{
	

	
	
	
	Set_angle(-2, -45,43,-90);//��2

	
		while(servo_flag!=1)
		{}
		Set_angle(-2, 35,43,-90);//��2

		while(servo_flag!=1)
		{}
			
Set_angle(-2, -45,43,-90);//��2


	while(servo_flag!=1)
		{}
		
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}
	
}
	
	
void gesan()
{

	
	
	
	Set_angle(-12, -45,41,-90);//����

	
		while(servo_flag!=1)
		{}
		Set_angle(-12, 35,41,-90);//����

		while(servo_flag!=1)
		{}
			
 Set_angle(-12, -45,41,-90);//����


	while(servo_flag!=1)
		{}
		
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}
	
}
			
void zuoyi(void)
{


Set_angle(0, -45,0,0);//

	while(servo_flag!=1)
	{}		
	
		Set_angle(-25, -45,42,-90);//��1

	
		while(servo_flag!=1)
		{}
		Set_angle(-25, 35,42,-90);//��1

		while(servo_flag!=1)
		{}
			
 	Set_angle(-25, -45,42,-90);//��1


	while(servo_flag!=1)
		{}
		
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}
	
}
	
	
		

	
void youer(void)
{
		

		
	Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}
		Set_angle(19, -45,33,-90);//you��

	while(servo_flag!=1)
	{}
	
Set_angle(19, 40,33,-90);//you��


while(servo_flag!=1)
		{}



Set_angle(19, -45,33,-90);//you��

	while(servo_flag!=1)
	{}



Set_angle(0, -45,0,0);

	while(servo_flag!=1)
	{}

}

void youyi(void)
{
    Set_angle(0, -45, 0, 0); // ��һ
    while (servo_flag != 1) {}
    // �������� servo_flag
    servo_flag = 0;

    Set_angle(21, -45, 44, -90); // ��һ
    while (servo_flag != 1) {}
    servo_flag = 0;

    Set_angle(21, 35, 44, -90); // ��һ
    while (servo_flag != 1) {}
    servo_flag = 0;

    Set_angle(21, -45, 44, -90); // ��һ
    while (servo_flag != 1) {}
    servo_flag = 0;

    Set_angle(0, -45, 0, 0); // �ָ�����ʼ�Ƕ�
    while (servo_flag != 1) {}
    servo_flag = 0;
}




void zuoer(void)
{


Set_angle(0, -45,0,0);//

	while(servo_flag!=1)
	{}		
	
		Set_angle(-22, -45,32,-90);//���

	
		while(servo_flag!=1)
		{}
		Set_angle(-22, 40,32,-90);//���

		while(servo_flag!=1)
		{}
			
 	Set_angle(-22, -45,32,-90);//���


	while(servo_flag!=1)
		{}
		
	 Set_angle(0, -45,0,0);//
	 

	while(servo_flag!=1)
	{}

}

void gewu(void)
{


    Set_angle(-1, -45, 31, -89); // ����
    while (servo_flag != 1) {}
    servo_flag = 0;

    Set_angle(-1, 42, 31, -89); // ����
    while (servo_flag != 1) {}
    servo_flag = 0;

    Set_angle(-1, -45, 31, -89); // ����
    while (servo_flag != 1) {}
    servo_flag = 0;

    Set_angle(0, -45, 0, 0); // �ָ�����ʼ�Ƕ�
    while (servo_flag != 1) {}
    servo_flag = 0;
}