#ifndef MOTOR_H
#define MOTOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f1xx_hal.h"

	
	
float get_speed();
float calculate_wheel_speed(int encoder_pulses, int cpr, float sample_period, int gear_ratio, float wheel_radius_mm);
void motor_forward();
void motor_reverse();
void motor_stop();

	
	
	
	
#ifdef __cplusplus
}
#endif

#endif 

